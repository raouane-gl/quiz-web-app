[CmdletBinding()]
param(
    [string]$PhpExe = "C:\\xampp\\php\\php.exe",
    [string]$MySqlExe = "C:\\xampp\\mysql\\bin\\mysql.exe",
    [string]$MySqlAdminExe = "C:\\xampp\\mysql\\bin\\mysqladmin.exe",
    [string]$MySqlDExe = "C:\\xampp\\mysql\\bin\\mysqld.exe",
    [string]$MySqlDefaultsFile = "C:\\xampp\\mysql\\bin\\my.ini",
    [string]$DbName = "quiz_platform",
    [string]$DbUser = "quiz_user",
    [string]$DbPass = "1234",
    [string]$MySqlRootUser = "root",
    [string]$MySqlRootPassword = "",
    [string]$HostAddress = "127.0.0.1",
    [int]$Port = 8000,
    [switch]$ResetDb,
    [switch]$SkipDbSetup
)
$ErrorActionPreference = 'Stop'
function Assert-FileExists([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "$Label not found: $Path"
    }
}
function Get-MySqlAuthArgs([string]$User, [string]$Password) {
    $userValue = $User
    if ($null -eq $userValue) { $userValue = '' }
    $userTrimmed = $userValue.Trim()
    if ($userTrimmed -eq '') {
        throw 'MySQL username cannot be empty.'
    }
    $args = @('-u', $userTrimmed)
    if ($null -ne $Password -and $Password.Trim() -ne '') {
        $args += "-p$Password"
    }
    return $args
}
function Invoke-MySql([string]$Query) {
    $auth = Get-MySqlAuthArgs -User $MySqlRootUser -Password $MySqlRootPassword
    & $MySqlExe @auth -e $Query | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "MySQL command failed (exit $LASTEXITCODE)."
    }
}
function Test-MySqlLogin([string]$User, [string]$Password) {
    $auth = Get-MySqlAuthArgs -User $User -Password $Password
    & $MySqlExe @auth -e "SELECT 1;" 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}
function Wait-MySqlReady([int]$TimeoutSeconds = 20) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $auth = Get-MySqlAuthArgs -User $MySqlRootUser -Password $MySqlRootPassword
    while ((Get-Date) -lt $deadline) {
        try {
            $out = & $MySqlAdminExe @auth ping 2>$null
            if ($out -match 'alive') { return }
        } catch {}
        Start-Sleep -Milliseconds 250
    }
    throw "MySQL did not become ready within ${TimeoutSeconds}s."
}
Write-Host "== Quiz Platform runner ==" -ForegroundColor Cyan
$ProjectRoot = $PSScriptRoot
$SqlFile = Join-Path $ProjectRoot 'database.sql'
Assert-FileExists $PhpExe 'PHP executable'
Assert-FileExists $MySqlExe 'MySQL client (mysql.exe)'
Assert-FileExists $MySqlAdminExe 'MySQL admin (mysqladmin.exe)'
Assert-FileExists $MySqlDExe 'MySQL server (mysqld.exe)'
Assert-FileExists $MySqlDefaultsFile 'MySQL defaults file (my.ini)'
Assert-FileExists $SqlFile 'database.sql'
$hasMysqli = & $PhpExe -r "echo extension_loaded('mysqli') ? 'yes' : 'no';"
if ($hasMysqli -ne 'yes') {
    throw "mysqli not enabled. Enable it in php.ini."
}
$mysqld = Get-Process -Name 'mysqld' -ErrorAction SilentlyContinue
if (-not $mysqld) {
    Write-Host "Starting MySQL (mysqld)..." -ForegroundColor Yellow
    Start-Process -FilePath $MySqlDExe -ArgumentList @(
        "--defaults-file=$MySqlDefaultsFile",
        "--standalone"
    ) -WindowStyle Hidden | Out-Null
} else {
    Write-Host "MySQL already running (PID $($mysqld.Id))." -ForegroundColor DarkGray
}
Write-Host "Waiting for MySQL to be ready..." -ForegroundColor Yellow
Wait-MySqlReady -TimeoutSeconds 20
if (-not $SkipDbSetup) {
    $rootOk = Test-MySqlLogin -User $MySqlRootUser -Password $MySqlRootPassword
    if (-not $rootOk) {
        Write-Warning "Cannot log in as root. Try -MySqlRootPassword 'YOUR_PASSWORD' or -SkipDbSetup."
        $appOk = Test-MySqlLogin -User $DbUser -Password $DbPass
        if (-not $appOk) {
            throw "MySQL root access required."
        }
    } else {
        if ($ResetDb) {
            Write-Host "Resetting database '$DbName'..." -ForegroundColor Yellow
            Invoke-MySql "DROP DATABASE IF EXISTS $DbName;"
        }
        Write-Host "Importing schema/data from database.sql..." -ForegroundColor Yellow
        Get-Content -LiteralPath $SqlFile -Raw | & $MySqlExe @(Get-MySqlAuthArgs -User $MySqlRootUser -Password $MySqlRootPassword) | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Import failed (exit $LASTEXITCODE)."
        }
        Write-Host "Ensuring DB user '$DbUser' exists..." -ForegroundColor Yellow
        Invoke-MySql "CREATE USER IF NOT EXISTS '$DbUser'@'localhost' IDENTIFIED BY '$DbPass';"
        Invoke-MySql "GRANT ALL PRIVILEGES ON $DbName.* TO '$DbUser'@'localhost';"
        Invoke-MySql "FLUSH PRIVILEGES;"
    }
}
try {
    $existing = Get-NetTCPConnection -LocalAddress $HostAddress -LocalPort $Port -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Warning "Port $Port already in use. Try: -Port 8080"
    }
} catch {}
$url = "http://$HostAddress`:$Port/"
Write-Host "Starting PHP dev server at $url" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop." -ForegroundColor DarkGray
Start-Process $url | Out-Null
Set-Location $ProjectRoot
& $PhpExe -S "$HostAddress`:$Port" -t $ProjectRoot