<?php
// =============================================
// admin/settings.php - Platform Settings
// =============================================
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAdmin();

$msg   = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $questions_per_quiz = (int) $_POST['questions_per_quiz'];
    $quiz_title         = trim(mysqli_real_escape_string($conn, $_POST['quiz_title']));
    $time_limit         = (int) $_POST['time_limit'];

    if ($questions_per_quiz < 1 || $questions_per_quiz > 100) {
        $error = 'Questions per quiz must be between 1 and 100.';
    } elseif (empty($quiz_title)) {
        $error = 'Quiz title cannot be empty.';
    } else {
        mysqli_query($conn,
            "UPDATE settings SET setting_value = '$questions_per_quiz' WHERE setting_key = 'questions_per_quiz'"
        );
        mysqli_query($conn,
            "UPDATE settings SET setting_value = '$quiz_title' WHERE setting_key = 'quiz_title'"
        );
        mysqli_query($conn,
            "UPDATE settings SET setting_value = '$time_limit' WHERE setting_key = 'time_limit'"
        );
        $msg = 'Settings saved successfully.';
    }
}

$questions_per_quiz = getSetting($conn, 'questions_per_quiz') ?: '10';
$quiz_title         = getSetting($conn, 'quiz_title') ?: 'Online Quiz Platform';
$time_limit         = getSetting($conn, 'time_limit') ?: '0';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body class="admin-page">

<?php include 'sidebar.php'; ?>

<div class="admin-content">
    <div class="admin-topbar">
        <h1 class="admin-page-title">
            <i class="fa-solid fa-sliders"></i> Settings
        </h1>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-check"></i> <?= $msg ?>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <div class="admin-card" style="max-width:560px;">
        <form method="POST">
            <div class="mb-4">
                <label class="form-label">Quiz Title</label>
                <input type="text" name="quiz_title" class="form-control custom-input"
                       value="<?= htmlspecialchars($quiz_title) ?>" required>
            </div>
            <div class="mb-4">
                <label class="form-label">Questions Per Quiz</label>
                <input type="number" name="questions_per_quiz" class="form-control custom-input"
                       value="<?= $questions_per_quiz ?>" min="1" max="100" required>
                <div style="font-size:0.82rem; color:var(--text-muted); margin-top:4px;">
                    How many random questions each user gets per session.
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label">Time Limit (minutes)</label>
                <input type="number" name="time_limit" class="form-control custom-input"
                       value="<?= $time_limit ?>" min="0" max="180">
                <div style="font-size:0.82rem; color:var(--text-muted); margin-top:4px;">
                    Set to 0 for no time limit.
                </div>
            </div>

            <!-- Difficulty distribution info -->
            <div style="background:var(--bg3); border:1px solid var(--border); border-radius:var(--radius-sm); padding:20px; margin-bottom:24px;">
                <div class="form-label" style="margin-bottom:12px;">
                    <i class="fa-solid fa-info-circle"></i> Difficulty Distribution
                </div>
                <div style="display:grid; grid-template-columns: repeat(3,1fr); gap:12px;">
                    <div style="text-align:center; padding:12px; background:var(--bg2); border-radius:8px;">
                        <div class="badge-diff easy" style="margin:0 auto 8px; display:inline-block;">Easy</div>
                        <div style="font-family:'Syne',sans-serif; font-size:0.8rem; color:var(--text-muted);">80% easy / 20% medium</div>
                    </div>
                    <div style="text-align:center; padding:12px; background:var(--bg2); border-radius:8px;">
                        <div class="badge-diff medium" style="margin:0 auto 8px; display:inline-block;">Medium</div>
                        <div style="font-family:'Syne',sans-serif; font-size:0.8rem; color:var(--text-muted);">40% easy / 50% medium / 10% hard</div>
                    </div>
                    <div style="text-align:center; padding:12px; background:var(--bg2); border-radius:8px;">
                        <div class="badge-diff hard" style="margin:0 auto 8px; display:inline-block;">Hard</div>
                        <div style="font-family:'Syne',sans-serif; font-size:0.8rem; color:var(--text-muted);">20% easy / 40% medium / 40% hard</div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-start">
                <i class="fa-solid fa-floppy-disk"></i> Save Settings
            </button>
        </form>
    </div>
</div>

</body>
</html>