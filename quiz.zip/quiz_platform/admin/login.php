<?php
// =============================================
// admin/login.php - Admin Login
// =============================================
session_start();
require_once '../includes/db.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(mysqli_real_escape_string($conn, $_POST['username']));
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $result = mysqli_query($conn, "SELECT * FROM admins WHERE username = '$username'");
        $admin  = mysqli_fetch_assoc($result);

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['username'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="admin-login-page">

<div class="admin-login-wrap">
    <div class="login-card">
        <div class="login-icon">
            <i class="fa-solid fa-shield-halved"></i>
        </div>
        <h2 class="login-title">Admin Login</h2>
        <p class="login-sub">Sign in to manage your quiz platform</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="login-form">
            <div class="form-group">
                <label class="form-label" for="username">Username</label>
                <input type="text"
                       class="form-control custom-input"
                       id="username"
                       name="username"
                       value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>"
                       required
                       autofocus>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input type="password"
                       class="form-control custom-input"
                       id="password"
                       name="password"
                       required>
            </div>

            <button type="submit" class="btn btn-start btn-full">
                <i class="fa-solid fa-right-to-bracket"></i>
                Login
            </button>
        </form>

        <div class="login-footer">
            <a href="../index.php" class="login-back">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Quiz
            </a>
        </div>
    </div>
</div>

</body>
</html>