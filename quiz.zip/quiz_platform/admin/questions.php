<?php
// =============================================
// admin/questions.php - Manage Questions
// =============================================
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAdmin();

$action  = $_GET['action'] ?? 'list';
$msg     = '';
$error   = '';
$edit_q  = null;
$edit_answers = [];

// ---- DELETE ----
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    mysqli_query($conn, "DELETE FROM questions WHERE id = $id");
    header("Location: questions.php?msg=deleted");
    exit();
}

// ---- SAVE (Add or Edit) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_question'])) {
    $q_id       = (int) ($_POST['q_id'] ?? 0);
    $q_text     = trim(mysqli_real_escape_string($conn, $_POST['question_text']));
    $q_type     = in_array($_POST['type'], ['SCQ', 'MCQ']) ? $_POST['type'] : 'SCQ';
    $q_diff     = in_array($_POST['difficulty'], ['easy', 'medium', 'hard'])
                  ? $_POST['difficulty'] : 'medium';
    $q_cat      = (int) $_POST['category_id'];
    $ans_texts  = $_POST['answer_text'] ?? [];
    $correct_ids = $_POST['correct'] ?? [];

    if (empty($q_text)) {
        $error = 'Question text is required.';
    } elseif (count(array_filter($ans_texts, 'trim')) < 2) {
        $error = 'At least 2 answers are required.';
    } elseif (empty($correct_ids)) {
        $error = 'At least one correct answer must be selected.';
    } else {
        if ($q_id > 0) {
            mysqli_query($conn,
                "UPDATE questions
                 SET question_text='$q_text', type='$q_type', difficulty='$q_diff', category_id=$q_cat
                 WHERE id=$q_id"
            );
            mysqli_query($conn, "DELETE FROM answers WHERE question_id = $q_id");
        } else {
            mysqli_query($conn,
                "INSERT INTO questions (question_text, type, difficulty, category_id)
                 VALUES ('$q_text','$q_type','$q_diff',$q_cat)"
            );
            $q_id = mysqli_insert_id($conn);
        }

        foreach ($ans_texts as $idx => $ans_text) {
            $ans_text = trim(mysqli_real_escape_string($conn, $ans_text));
            if ($ans_text === '') continue;
            $is_correct = in_array($idx, $correct_ids) ? 1 : 0;
            mysqli_query($conn,
                "INSERT INTO answers (question_id, answer_text, is_correct)
                 VALUES ($q_id, '$ans_text', $is_correct)"
            );
        }

        header("Location: questions.php?msg=saved");
        exit();
    }
}

// ---- EDIT: load question ----
if ($action === 'edit' && isset($_GET['id'])) {
    $id     = (int) $_GET['id'];
    $res    = mysqli_query($conn, "SELECT * FROM questions WHERE id = $id");
    $edit_q = mysqli_fetch_assoc($res);
    $ans_r  = mysqli_query($conn, "SELECT * FROM answers WHERE question_id = $id");
    while ($r = mysqli_fetch_assoc($ans_r)) {
        $edit_answers[] = $r;
    }
}

// Flash messages
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'saved')   $msg = 'Question saved successfully.';
    if ($_GET['msg'] === 'deleted') $msg = 'Question deleted.';
}

// Get categories
$cats_r   = mysqli_query($conn, "SELECT * FROM categories");
$categories = [];
while ($r = mysqli_fetch_assoc($cats_r)) { $categories[] = $r; }

// Filter
$filter_diff = $_GET['filter_diff'] ?? '';
$filter_cat  = $_GET['filter_cat']  ?? '';

$where = [];
if ($filter_diff) $where[] = "q.difficulty='".mysqli_real_escape_string($conn, $filter_diff)."'";
if ($filter_cat)  $where[] = "q.category_id='".mysqli_real_escape_string($conn, $filter_cat)."'";
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Get questions
$questions_r = mysqli_query($conn,
    "SELECT q.*, c.name as cat_name,
     (SELECT COUNT(*) FROM answers WHERE question_id = q.id) as ans_count
     FROM questions q
     LEFT JOIN categories c ON q.category_id = c.id
     $where_sql
     ORDER BY q.created_at DESC"
);
$questions = [];
while ($r = mysqli_fetch_assoc($questions_r)) { $questions[] = $r; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body class="admin-page">

<?php include 'sidebar.php'; ?>

<div class="admin-content">
    <div class="admin-topbar">
        <h1 class="admin-page-title">
            <?= ($action === 'add' || $action === 'edit')
               ? ($edit_q ? '<i class="fa-solid fa-pen"></i> Edit Question' : '<i class="fa-solid fa-plus"></i> Add Question')
               : '<i class="fa-solid fa-circle-question"></i> Manage Questions' ?>
        </h1>
        <?php if ($action === 'list'): ?>
            <a href="questions.php?action=add" class="btn btn-start">
                <i class="fa-solid fa-plus"></i> Add Question
            </a>
        <?php else: ?>
            <a href="questions.php" class="btn-ghost">
                <i class="fa-solid fa-arrow-left"></i> Back to List
            </a>
        <?php endif; ?>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-check"></i> <?= $msg ?>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- ADD / EDIT FORM -->
    <div class="admin-card">
        <form method="POST" action="questions.php" id="questionForm">
            <input type="hidden" name="q_id" value="<?= $edit_q['id'] ?? 0 ?>">

            <div class="row mb-4">
                <div class="col-md-8">
                    <label class="form-label">Question Text *</label>
                    <textarea name="question_text"
                              class="form-control custom-input"
                              rows="4"
                              placeholder="Enter your question here..."
                              required><?= htmlspecialchars($edit_q['question_text'] ?? '') ?></textarea>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="type" class="form-select custom-input" id="qtype">
                            <option value="SCQ" <?= ($edit_q['type'] ?? 'SCQ') === 'SCQ' ? 'selected' : '' ?>>
                                SCQ (Single Choice)
                            </option>
                            <option value="MCQ" <?= ($edit_q['type'] ?? '') === 'MCQ' ? 'selected' : '' ?>>
                                MCQ (Multiple Choice)
                            </option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Difficulty</label>
                        <select name="difficulty" class="form-select custom-input">
                            <option value="easy"   <?= ($edit_q['difficulty'] ?? 'medium') === 'easy'   ? 'selected' : '' ?>>Easy</option>
                            <option value="medium" <?= ($edit_q['difficulty'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>Medium</option>
                            <option value="hard"   <?= ($edit_q['difficulty'] ?? '') === 'hard'   ? 'selected' : '' ?>>Hard</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Category</label>
                        <select name="category_id" class="form-select custom-input">
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"
                                        <?= ($edit_q['category_id'] ?? 1) == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Answers -->
            <div class="mb-4">
                <label class="form-label">
                    Answers <small style="color:var(--text-muted); font-weight:400;">(mark correct answer(s) with radio/checkbox)</small>
                </label>
                <div id="answersContainer">
                    <?php
                    $prefill = !empty($edit_answers)
                        ? $edit_answers
                        : [
                            ['answer_text' => '', 'is_correct' => 0],
                            ['answer_text' => '', 'is_correct' => 0],
                            ['answer_text' => '', 'is_correct' => 0],
                            ['answer_text' => '', 'is_correct' => 0],
                          ];
                    foreach ($prefill as $idx => $ans):
                    ?>
                    <div class="answer-row mb-2 d-flex align-items-center gap-2">
                        <input type="<?= ($edit_q['type'] ?? 'SCQ') === 'SCQ' ? 'radio' : 'checkbox' ?>"
                               name="correct[]"
                               value="<?= $idx ?>"
                               <?= $ans['is_correct'] ? 'checked' : '' ?>
                               class="correct-input">
                        <input type="text"
                               name="answer_text[]"
                               class="form-control custom-input"
                               placeholder="Answer <?= $idx + 1 ?>"
                               value="<?= htmlspecialchars($ans['answer_text']) ?>">
                        <?php if ($idx >= 2): ?>
                        <button type="button" class="btn-danger-ghost remove-answer" style="padding:6px 10px;">
                            <i class="fa-solid fa-times"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" id="addAnswer" class="btn-ghost mt-2">
                    <i class="fa-solid fa-plus"></i> Add Answer
                </button>
            </div>

            <button type="submit" name="save_question" class="btn btn-start">
                <i class="fa-solid fa-floppy-disk"></i>
                <?= $edit_q ? 'Update Question' : 'Save Question' ?>
            </button>
        </form>
    </div>

    <?php else: ?>
    <!-- QUESTIONS LIST + FILTERS -->
    <div class="admin-card">
        <!-- Filters -->
        <form method="GET" style="display:flex; gap:12px; align-items:center; margin-bottom:20px; flex-wrap:wrap;">
            <div>
                <label class="form-label" style="margin-bottom:2px;">Difficulty</label>
                <select name="filter_diff" class="form-select custom-input" style="min-width:120px;">
                    <option value="">All</option>
                    <option value="easy"   <?= $filter_diff === 'easy'   ? 'selected' : '' ?>>Easy</option>
                    <option value="medium" <?= $filter_diff === 'medium' ? 'selected' : '' ?>>Medium</option>
                    <option value="hard"   <?= $filter_diff === 'hard'   ? 'selected' : '' ?>>Hard</option>
                </select>
            </div>
            <div>
                <label class="form-label" style="margin-bottom:2px;">Category</label>
                <select name="filter_cat" class="form-select custom-input" style="min-width:150px;">
                    <option value="">All</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $filter_cat == $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-ghost" style="align-self:flex-end;">
                <i class="fa-solid fa-filter"></i> Filter
            </button>
            <a href="questions.php" class="btn-ghost" style="align-self:flex-end;">
                <i class="fa-solid fa-xmark"></i> Clear
            </a>
        </form>

        <div class="table-responsive">
            <table class="table admin-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Question</th>
                        <th>Type</th>
                        <th>Category</th>
                        <th>Difficulty</th>
                        <th>Answers</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($questions as $i => $q): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td style="max-width:280px;"><?= htmlspecialchars(substr($q['question_text'], 0, 80)) ?>...</td>
                        <td><span class="badge-type <?= strtolower($q['type']) ?>"><?= $q['type'] ?></span></td>
                        <td><?= htmlspecialchars($q['cat_name'] ?? '-') ?></td>
                        <td><span class="badge-diff <?= $q['difficulty'] ?>"><?= ucfirst($q['difficulty']) ?></span></td>
                        <td><?= $q['ans_count'] ?></td>
                        <td>
                            <a href="questions.php?action=edit&id=<?= $q['id'] ?>"
                               class="btn-ghost" style="padding:6px 12px; font-size:0.82rem;">
                                <i class="fa-solid fa-pen"></i> Edit
                            </a>
                            <a href="questions.php?action=delete&id=<?= $q['id'] ?>"
                               class="btn-danger-ghost" style="padding:6px 12px; font-size:0.82rem;"
                               onclick="return confirm('Delete this question?');">
                                <i class="fa-solid fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($questions)): ?>
                    <tr><td colspan="7" class="text-center text-muted py-4">No questions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
(function() {
    // Toggle radio/checkbox based on question type
    document.getElementById('qtype')?.addEventListener('change', function() {
        var type = this.value;
        document.querySelectorAll('.correct-input').forEach(function(inp) {
            inp.type = type === 'SCQ' ? 'radio' : 'checkbox';
        });
    });

    // Add answer row
    var answerCount = <?= max(count($prefill ?? [4]), 4) ?>;
    document.getElementById('addAnswer')?.addEventListener('click', function() {
        var container = document.getElementById('answersContainer');
        var type = document.getElementById('qtype').value;
        var row = document.createElement('div');
        row.className = 'answer-row mb-2 d-flex align-items-center gap-2';
        row.innerHTML =
            '<input type="' + (type === 'SCQ' ? 'radio' : 'checkbox') + '" ' +
            'name="correct[]" value="' + answerCount + '" class="correct-input">' +
            '<input type="text" name="answer_text[]" class="form-control custom-input" ' +
            'placeholder="Answer ' + (answerCount + 1) + '">' +
            '<button type="button" class="btn-danger-ghost remove-answer" style="padding:6px 10px;">' +
            '<i class="fa-solid fa-times"></i></button>';
        container.appendChild(row);
        answerCount++;
    });

    // Remove answer row
    document.addEventListener('click', function(e) {
        if (e.target.closest('.remove-answer')) {
            e.target.closest('.answer-row').remove();
        }
    });
})();
</script>
</body>
</html>