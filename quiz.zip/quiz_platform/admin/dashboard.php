<?php
// =============================================
// admin/dashboard.php - Admin Dashboard
// =============================================
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAdmin();

// Stats
$total_questions = (int) mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) as c FROM questions")
)['c'];
$total_sessions = (int) mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) as c FROM quiz_sessions WHERE is_completed = 1")
)['c'];
$avg_score_row  = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT AVG(score/total*100) as avg FROM quiz_sessions WHERE is_completed = 1 AND total > 0")
);
$avg_score      = $avg_score_row['avg'] ? round($avg_score_row['avg'], 1) : 0;
$total_cats     = (int) mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) as c FROM categories")
)['c'];

// Difficulty breakdown
$diff_easy   = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM questions WHERE difficulty='easy'"))['c'];
$diff_medium = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM questions WHERE difficulty='medium'"))['c'];
$diff_hard   = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM questions WHERE difficulty='hard'"))['c'];

// Recent attempts
$recent = mysqli_query($conn,
    "SELECT username, score, total, submitted_at
     FROM quiz_sessions
     WHERE is_completed = 1
     ORDER BY submitted_at DESC
     LIMIT 5"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="admin-page">

<?php include 'sidebar.php'; ?>

<div class="admin-content">

    <!-- Header -->
    <div class="admin-topbar">
        <h1 class="admin-page-title">Dashboard</h1>
        <span class="admin-welcome">
            <i class="fa-solid fa-user-shield"></i>
            <?= htmlspecialchars($_SESSION['admin_name']) ?>
        </span>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon-wrap pink">
                <i class="fa-solid fa-circle-question"></i>
            </div>
            <div class="stat-num"><?= $total_questions ?></div>
            <div class="stat-label">Questions</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon-wrap blue">
                <i class="fa-solid fa-pen-clip"></i>
            </div>
            <div class="stat-num"><?= $total_sessions ?></div>
            <div class="stat-label">Quizzes Done</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon-wrap teal">
                <i class="fa-solid fa-chart-line"></i>
            </div>
            <div class="stat-num"><?= $avg_score ?>%</div>
            <div class="stat-label">Avg Score</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon-wrap pink">
                <i class="fa-solid fa-layer-group"></i>
            </div>
            <div class="stat-num"><?= $total_cats ?></div>
            <div class="stat-label">Categories</div>
        </div>
    </div>

    <!-- Two column layout -->
    <div class="dash-grid">

        <!-- Difficulty distribution -->
        <div class="admin-card">
            <div class="card-header">
                <h3 class="card-section-title">Difficulty Distribution</h3>
            </div>
            <div class="diff-bars">
                <div class="diff-row">
                    <span class="badge-diff easy">Easy</span>
                    <div class="diff-bar-wrap">
                        <div class="diff-bar easy"
                             style="width:<?= $total_questions > 0 ? round($diff_easy/$total_questions*100) : 0 ?>%">
                        </div>
                    </div>
                    <span class="diff-count"><?= $diff_easy ?></span>
                </div>
                <div class="diff-row">
                    <span class="badge-diff medium">Medium</span>
                    <div class="diff-bar-wrap">
                        <div class="diff-bar medium"
                             style="width:<?= $total_questions > 0 ? round($diff_medium/$total_questions*100) : 0 ?>%">
                        </div>
                    </div>
                    <span class="diff-count"><?= $diff_medium ?></span>
                </div>
                <div class="diff-row">
                    <span class="badge-diff hard">Hard</span>
                    <div class="diff-bar-wrap">
                        <div class="diff-bar hard"
                             style="width:<?= $total_questions > 0 ? round($diff_hard/$total_questions*100) : 0 ?>%">
                        </div>
                    </div>
                    <span class="diff-count"><?= $diff_hard ?></span>
                </div>
            </div>
        </div>

        <!-- Quick actions -->
        <div class="admin-card">
            <div class="card-header">
                <h3 class="card-section-title">Quick Actions</h3>
            </div>
            <div class="action-list">
                <a href="questions.php?action=add" class="action-item">
                    <span class="action-icon"><i class="fa-solid fa-plus"></i></span>
                    <span class="action-text">
                        <strong>Add Question</strong>
                        <small>Create a new quiz question</small>
                    </span>
                    <i class="fa-solid fa-chevron-right action-arrow"></i>
                </a>
                <a href="questions.php" class="action-item">
                    <span class="action-icon"><i class="fa-solid fa-list"></i></span>
                    <span class="action-text">
                        <strong>Manage Questions</strong>
                        <small>Edit or delete questions</small>
                    </span>
                    <i class="fa-solid fa-chevron-right action-arrow"></i>
                </a>
                <a href="attempts.php" class="action-item">
                    <span class="action-icon"><i class="fa-solid fa-clock-rotate-left"></i></span>
                    <span class="action-text">
                        <strong>View Attempts</strong>
                        <small>See all quiz results</small>
                    </span>
                    <i class="fa-solid fa-chevron-right action-arrow"></i>
                </a>
                <a href="settings.php" class="action-item">
                    <span class="action-icon"><i class="fa-solid fa-sliders"></i></span>
                    <span class="action-text">
                        <strong>Settings</strong>
                        <small>Configure platform</small>
                    </span>
                    <i class="fa-solid fa-chevron-right action-arrow"></i>
                </a>
            </div>
        </div>

    </div>

    <!-- Recent attempts -->
    <div class="admin-card">
        <div class="card-header">
            <h3 class="card-section-title">Recent Attempts</h3>
        </div>
        <?php if (mysqli_num_rows($recent) === 0): ?>
            <p class="empty-state">No completed quizzes yet.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table admin-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Score</th>
                            <th>Percentage</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($recent)): ?>
                            <?php $pct = $row['total'] > 0 ? round($row['score'] / $row['total'] * 100) : 0; ?>
                            <tr>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td><?= $row['score'] ?>/<?= $row['total'] ?></td>
                                <td>
                                    <div class="score-cell">
                                        <div class="progress" style="height:6px; width:80px;">
                                            <div class="progress-bar" style="width:<?= $pct ?>%"></div>
                                        </div>
                                        <span class="pct-label"><?= $pct ?>%</span>
                                    </div>
                                </td>
                                <td class="date-cell"><?= date('Y-m-d H:i', strtotime($row['submitted_at'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>