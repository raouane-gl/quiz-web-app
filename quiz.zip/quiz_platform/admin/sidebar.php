<?php
// admin/sidebar.php - Shared Sidebar
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="admin-sidebar">
    <div class="sidebar-logo">
        <i class="fa-solid fa-gear"></i>
        Admin
    </div>
    <nav class="sidebar-nav">
        <a href="dashboard.php"
           class="nav-item <?= $current_page === 'dashboard.php' ? 'active' : '' ?>">
            <span class="nav-icon"><i class="fa-solid fa-chart-pie"></i></span>
            Dashboard
        </a>
        <a href="questions.php"
           class="nav-item <?= $current_page === 'questions.php' ? 'active' : '' ?>">
            <span class="nav-icon"><i class="fa-solid fa-circle-question"></i></span>
            Questions
        </a>
        <a href="attempts.php"
           class="nav-item <?= $current_page === 'attempts.php' ? 'active' : '' ?>">
            <span class="nav-icon"><i class="fa-solid fa-pen-clip"></i></span>
            Attempts
        </a>
        <a href="settings.php"
           class="nav-item <?= $current_page === 'settings.php' ? 'active' : '' ?>">
            <span class="nav-icon"><i class="fa-solid fa-sliders"></i></span>
            Settings
        </a>
    </nav>
    <div class="sidebar-footer">
        <a href="logout.php" class="nav-item logout-btn">
            <span class="nav-icon"><i class="fa-solid fa-right-from-bracket"></i></span>
            Logout
        </a>
        <a href="../index.php" class="nav-item" target="_blank">
            <span class="nav-icon"><i class="fa-solid fa-globe"></i></span>
            View Site
        </a>
    </div>
</div>