<?php
// =============================================
// admin/attempts.php - View User Attempts
// =============================================
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAdmin();

// Filter by username
$search = trim(mysqli_real_escape_string($conn, $_GET['search'] ?? ''));
$where  = $search ? "WHERE username LIKE '%$search%'" : '';

$attempts_r = mysqli_query($conn,
    "SELECT qs.*, ROUND(qs.score/qs.total*100, 1) as pct
     FROM quiz_sessions qs
     $where
     ORDER BY qs.submitted_at DESC"
);
$attempts = [];
while ($r = mysqli_fetch_assoc($attempts_r)) { $attempts[] = $r; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Attempts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body class="admin-page">

<?php include 'sidebar.php'; ?>

<div class="admin-content">
    <div class="admin-topbar">
        <h1 class="admin-page-title">
            <i class="fa-solid fa-pen-clip"></i> User Attempts
        </h1>
        <span class="text-muted"><?= count($attempts) ?> completed quizzes</span>
    </div>

    <!-- Search -->
    <form method="GET" style="display:flex; gap:12px; margin-bottom:20px; align-items:flex-end;">
        <div style="flex:1; max-width:300px;">
            <label class="form-label" style="margin-bottom:2px;">Search by Username</label>
            <input type="text" name="search" class="form-control custom-input"
                   value="<?= htmlspecialchars($search) ?>"
                   placeholder="e.g. amina123">
        </div>
        <button type="submit" class="btn-ghost">
            <i class="fa-solid fa-magnifying-glass"></i> Search
        </button>
        <?php if ($search): ?>
            <a href="attempts.php" class="btn-ghost">
                <i class="fa-solid fa-xmark"></i> Clear
            </a>
        <?php endif; ?>
    </form>

    <div class="admin-card">
        <div class="table-responsive">
            <table class="table admin-table">
                <thead>
                    <tr>
                        <th><i class="fa-solid fa-hashtag"></i> #</th>
                        <th><i class="fa-solid fa-user"></i> Username</th>
                        <th><i class="fa-solid fa-check-double"></i> Score</th>
                        <th><i class="fa-solid fa-percent"></i> Percentage</th>
                        <th><i class="fa-solid fa-award"></i> Grade</th>
                        <th><i class="fa-solid fa-calendar"></i> Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attempts as $i => $a): ?>
                        <?php
                        $pct = $a['total'] > 0 ? round($a['score'] / $a['total'] * 100) : 0;
                        if ($pct >= 90)      { $grade = 'Excellent';  $gc = 'grade-excellent'; }
                        elseif ($pct >= 75)   { $grade = 'Very Good';  $gc = 'grade-vgood'; }
                        elseif ($pct >= 60)   { $grade = 'Good';        $gc = 'grade-good'; }
                        elseif ($pct >= 50)   { $grade = 'Pass';        $gc = 'grade-pass'; }
                        else                  { $grade = 'Needs Review'; $gc = 'grade-fail'; }
                        ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= htmlspecialchars($a['username']) ?></td>
                            <td><?= $a['score'] ?>/<?= $a['total'] ?></td>
                            <td>
                                <div class="progress" style="height:8px; min-width:80px;">
                                    <div class="progress-bar" style="width:<?= $pct ?>%"></div>
                                </div>
                                <small style="color:var(--text-muted)"><?= $pct ?>%</small>
                            </td>
                            <td><span class="badge-diff <?= $gc ?>"><?= $grade ?></span></td>
                            <td><?= date('Y-m-d H:i', strtotime($a['submitted_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($attempts)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No attempts found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>