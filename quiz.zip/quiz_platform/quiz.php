<?php
// =============================================
// quiz.php - Quiz Interface
// =============================================
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
requireQuizSession();

$session_id = $_SESSION['quiz_session_id'];
$username    = $_SESSION['username'];
$difficulty  = $_SESSION['quiz_difficulty'] ?? 'medium';

// Guard: redirect if session already completed
$sess_data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM quiz_sessions WHERE id = $session_id")
);
if ($sess_data['is_completed']) {
    header("Location: results.php");
    exit();
}

// Load all questions for this session
$questions_result = mysqli_query($conn,
    "SELECT q.*, c.name AS category_name
     FROM session_questions sq
     JOIN questions q ON sq.question_id = q.id
     LEFT JOIN categories c ON q.category_id = c.id
     WHERE sq.session_id = $session_id
     ORDER BY sq.id"
);
$questions = [];
while ($row = mysqli_fetch_assoc($questions_result)) {
    $questions[] = $row;
}
$total = count($questions);

// ---- HANDLE ANSWER SUBMIT ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_answer'])) {
    $question_id = (int) $_POST['question_id'];
    $q_type     = $_POST['q_type'];

    // Remove previous answer for this question (allow re-answering)
    mysqli_query($conn,
        "DELETE FROM user_answers WHERE session_id = $session_id AND question_id = $question_id"
    );

    if ($q_type === 'SCQ') {
        if (!empty($_POST['answer'])) {
            $answer_id = (int) $_POST['answer'];
            mysqli_query($conn,
                "INSERT INTO user_answers (session_id, question_id, answer_id) VALUES ($session_id, $question_id, $answer_id)"
            );
        }
    } else {
        if (!empty($_POST['answers']) && is_array($_POST['answers'])) {
            foreach ($_POST['answers'] as $answer_id) {
                $answer_id = (int) $answer_id;
                mysqli_query($conn,
                    "INSERT INTO user_answers (session_id, question_id, answer_id) VALUES ($session_id, $question_id, $answer_id)"
                );
            }
        }
    }

    $_SESSION['question_index']++;

    // Last question: calculate score and finalize
    if ($_SESSION['question_index'] >= $total) {
        $score = 0;
        foreach ($questions as $q) {
            $qid = $q['id'];

            $ua = mysqli_query($conn,
                "SELECT answer_id FROM user_answers WHERE session_id = $session_id AND question_id = $qid"
            );
            $user_ans = [];
            while ($r = mysqli_fetch_assoc($ua)) {
                $user_ans[] = $r['answer_id'];
            }

            $ca = mysqli_query($conn,
                "SELECT id FROM answers WHERE question_id = $qid AND is_correct = 1"
            );
            $correct_ans = [];
            while ($r = mysqli_fetch_assoc($ca)) {
                $correct_ans[] = $r['id'];
            }

            sort($user_ans);
            sort($correct_ans);
            if ($user_ans == $correct_ans) {
                $score++;
            }
        }

        mysqli_query($conn,
            "UPDATE quiz_sessions
             SET is_completed = 1, submitted_at = NOW(), score = $score, total = $total
             WHERE id = $session_id"
        );

        $_SESSION['final_score'] = $score;
        $_SESSION['final_total'] = $total;

        header("Location: results.php");
        exit();
    }

    header("Location: quiz.php");
    exit();
}

// Validate current index
$current_index = $_SESSION['question_index'];
if ($current_index >= $total) {
    header("Location: results.php");
    exit();
}

$current_q = $questions[$current_index];
$qid       = $current_q['id'];
$progress  = round((($current_index + 1) / $total) * 100);

// Shuffle answers for display (but track correct IDs separately)
$answers_result = mysqli_query($conn,
    "SELECT * FROM answers WHERE question_id = $qid ORDER BY RAND()"
);
$answers = [];
while ($row = mysqli_fetch_assoc($answers_result)) {
    $answers[] = $row;
}

$quiz_title = getSetting($conn, 'quiz_title') ?: 'Online Quiz Platform';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz - <?= htmlspecialchars($quiz_title) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="quiz-page">

<div class="quiz-wrapper">

    <!-- Header -->
    <div class="quiz-header">
        <div class="quiz-logo">Q<span>uiz</span></div>
        <div class="quiz-user">
            <i class="fa-solid fa-user"></i>
            <?= htmlspecialchars($username) ?>
        </div>
    </div>

    <!-- Progress -->
    <div class="quiz-progress-wrap">
        <div class="progress-info">
            <span>
                Question <?= $current_index + 1 ?> of <?= $total ?>
                &mdash; <span class="badge-diff <?= $difficulty ?>"><?= ucfirst($difficulty) ?></span>
            </span>
            <span><?= $progress ?>%</span>
        </div>
        <div class="progress quiz-progress">
            <div class="progress-bar" style="width: <?= $progress ?>%"></div>
        </div>
    </div>

    <!-- Question Card -->
    <div class="question-card">

        <div class="question-meta">
            <span class="badge-type <?= strtolower($current_q['type']) ?>">
                <?= $current_q['type'] ?>
            </span>
            <?php if ($current_q['category_name']): ?>
                <span class="badge-cat"><?= htmlspecialchars($current_q['category_name']) ?></span>
            <?php endif; ?>
            <span class="badge-diff <?= $current_q['difficulty'] ?>">
                <?= ucfirst($current_q['difficulty']) ?>
            </span>
        </div>

        <h2 class="question-text"><?= htmlspecialchars($current_q['question_text']) ?></h2>

        <?php if ($current_q['type'] === 'MCQ'): ?>
            <p class="mcq-hint">
                <i class="fa-solid fa-lightbulb"></i>
                Select all correct answers
            </p>
        <?php endif; ?>

        <form method="POST" action="quiz.php" id="answerForm">
            <input type="hidden" name="question_id" value="<?= $qid ?>">
            <input type="hidden" name="q_type" value="<?= $current_q['type'] ?>">

            <div class="answers-grid">
                <?php foreach ($answers as $i => $ans): ?>
                    <label class="answer-option" id="option-<?= $ans['id'] ?>">
                        <?php if ($current_q['type'] === 'SCQ'): ?>
                            <input type="radio" name="answer" value="<?= $ans['id'] ?>" required>
                        <?php else: ?>
                            <input type="checkbox" name="answers[]" value="<?= $ans['id'] ?>">
                        <?php endif; ?>
                        <span class="option-letter"><?= chr(65 + $i) ?></span>
                        <span class="option-text"><?= htmlspecialchars($ans['answer_text']) ?></span>
                        <span class="option-check"><i class="fa-solid fa-check"></i></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="quiz-actions">
                <button type="submit" name="submit_answer" class="btn btn-next">
                    <?php if ($current_index + 1 >= $total): ?>
                        <i class="fa-solid fa-flag-checkered"></i>
                        Submit Quiz
                    <?php else: ?>
                        <i class="fa-solid fa-arrow-right"></i>
                        Next Question
                    <?php endif; ?>
                </button>
            </div>
        </form>
    </div>

    <!-- Question dots navigation -->
    <div class="question-dots">
        <?php foreach ($questions as $i => $q): ?>
            <div class="dot <?= $i < $current_index ? 'done' : ($i === $current_index ? 'active' : '') ?>"></div>
        <?php endforeach; ?>
    </div>

</div>

<script>
(function() {
    var form = document.getElementById('answerForm');

    // Highlight selected answer
    document.querySelectorAll('.answer-option').forEach(function(label) {
        label.addEventListener('click', function() {
            var input = this.querySelector('input');
            if (input.type === 'radio') {
                document.querySelectorAll('.answer-option').forEach(function(l) {
                    l.classList.remove('selected');
                });
                this.classList.add('selected');
            } else {
                this.classList.toggle('selected', input.checked);
            }
        });
    });

    // MCQ validation: at least one checkbox must be selected
    form.addEventListener('submit', function(e) {
        var type = document.querySelector('input[name="q_type"]').value;
        if (type === 'MCQ') {
            var checked = document.querySelectorAll('input[name="answers[]"]:checked');
            if (checked.length === 0) {
                e.preventDefault();
                alert('Please select at least one answer.');
            }
        }
    });
})();
</script>
</body>
</html>