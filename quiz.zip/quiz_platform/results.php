<?php
// =============================================
// results.php - Quiz Results
// =============================================
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';
requireQuizSession();

$session_id = $_SESSION['quiz_session_id'];
$username   = $_SESSION['username'];

$sess = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM quiz_sessions WHERE id = $session_id")
);

if (!$sess['is_completed']) {
    header("Location: quiz.php");
    exit();
}

$score      = $sess['score'];
$total      = $sess['total'];
$percentage = $total > 0 ? round(($score / $total) * 100) : 0;

if ($percentage >= 90)      { $grade = 'Excellent'; $grade_class = 'grade-excellent'; }
elseif ($percentage >= 75)  { $grade = 'Very Good';  $grade_class = 'grade-vgood'; }
elseif ($percentage >= 60)  { $grade = 'Good';        $grade_class = 'grade-good'; }
elseif ($percentage >= 50)  { $grade = 'Pass';        $grade_class = 'grade-pass'; }
else                        { $grade = 'Needs Review'; $grade_class = 'grade-fail'; }

$questions_result = mysqli_query($conn,
    "SELECT q.id, q.question_text, q.type, q.difficulty
     FROM session_questions sq
     JOIN questions q ON sq.question_id = q.id
     WHERE sq.session_id = $session_id
     ORDER BY sq.id"
);

$quiz_title = getSetting($conn, 'quiz_title') ?: 'Online Quiz Platform';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results - <?= htmlspecialchars($quiz_title) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="results-page">

<div class="results-wrapper">

    <!-- Score Hero -->
    <div class="score-hero">
        <div class="score-circle <?= $grade_class ?>">
            <div class="score-num"><?= $percentage ?>%</div>
            <div class="score-label">Score</div>
        </div>
        <h1 class="grade-title <?= $grade_class ?>"><?= $grade ?></h1>
        <p class="score-detail">
            <strong><?= htmlspecialchars($username) ?></strong> answered
            <strong><?= $score ?></strong> out of <strong><?= $total ?></strong> correctly
        </p>
    </div>

    <!-- Answer Review -->
    <div class="review-section">
        <h3 class="review-title">
            <i class="fa-solid fa-list-check"></i>&nbsp; Answer Review
        </h3>

        <?php while ($q = mysqli_fetch_assoc($questions_result)): ?>
            <?php
            $qid = $q['id'];

            $ua = mysqli_query($conn,
                "SELECT answer_id FROM user_answers WHERE session_id = $session_id AND question_id = $qid"
            );
            $user_answers = [];
            while ($r = mysqli_fetch_assoc($ua)) {
                $user_answers[] = $r['answer_id'];
            }

            $all_a = mysqli_query($conn,
                "SELECT * FROM answers WHERE question_id = $qid"
            );
            $all_answers    = [];
            $correct_answers = [];
            while ($r = mysqli_fetch_assoc($all_a)) {
                $all_answers[] = $r;
                if ($r['is_correct']) $correct_answers[] = $r['id'];
            }

            sort($user_answers);
            sort($correct_answers);
            $is_correct = ($user_answers == $correct_answers);
            ?>

            <div class="review-card <?= $is_correct ? 'correct' : 'incorrect' ?>">
                <div class="review-q-header">
                    <span class="review-status">
                        <?php if ($is_correct): ?>
                            <i class="fa-solid fa-check"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-xmark"></i>
                        <?php endif; ?>
                    </span>
                    <span class="review-q-text"><?= htmlspecialchars($q['question_text']) ?></span>
                    <span class="badge-type <?= strtolower($q['type']) ?>"><?= $q['type'] ?></span>
                    <span class="badge-diff <?= $q['difficulty'] ?>"><?= ucfirst($q['difficulty']) ?></span>
                </div>
                <div class="review-answers">
                    <?php foreach ($all_answers as $ans): ?>
                        <?php
                        $user_picked = in_array($ans['id'], $user_answers);
                        $ans_correct = $ans['is_correct'];
                        $ans_class   = '';
                        if ($ans_correct)                    $ans_class = 'ans-correct';
                        elseif ($user_picked && !$ans_correct) $ans_class = 'ans-wrong';
                        ?>
                        <div class="review-ans-item <?= $ans_class ?>">
                            <span class="ans-icon">
                                <?php if ($ans_correct): ?>
                                    <i class="fa-solid fa-check"></i>
                                <?php elseif ($user_picked): ?>
                                    <i class="fa-solid fa-xmark"></i>
                                <?php else: ?>
                                    <i class="fa-regular fa-circle"></i>
                                <?php endif; ?>
                            </span>
                            <?= htmlspecialchars($ans['answer_text']) ?>
                            <?php if ($user_picked && !$ans_correct): ?>
                                <em>(your answer)</em>
                            <?php endif; ?>
                            <?php if ($ans_correct): ?>
                                <em>(correct)</em>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        <?php endwhile; ?>
    </div>

    <!-- Actions -->
    <div class="results-actions">
        <a href="index.php" class="btn btn-start">
            <i class="fa-solid fa-rotate-right"></i>
            Try Again
        </a>
    </div>

</div>

<script>
window.addEventListener('load', function() {
    var circle = document.querySelector('.score-circle');
    if (circle) {
        circle.style.transform = 'scale(1)';
    }
});
</script>
</body>
</html>