<?php
// =============================================
// index.php - Homepage + Quiz Settings
// =============================================
session_start();
require_once 'includes/db.php';

$error = '';

// ---- HANDLE FORM SUBMIT ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(mysqli_real_escape_string($conn, $_POST['username']));
    $count    = (int) ($_POST['question_count'] ?? 10);
    $difficulty = $_POST['difficulty'] ?? 'medium';

    if (empty($username)) {
        $error = 'Username is required.';
    } elseif (strlen($username) < 2 || strlen($username) > 50) {
        $error = 'Username must be 2-50 characters.';
    } elseif (!in_array($count, [5, 10, 15, 20])) {
        $error = 'Invalid question count.';
    } elseif (!in_array($difficulty, ['easy', 'medium', 'hard'])) {
        $error = 'Invalid difficulty level.';
    } else {
        // Check available questions
        $total_questions = (int) mysqli_fetch_assoc(
            mysqli_query($conn, "SELECT COUNT(*) as c FROM questions")
        )['c'];

        if ($total_questions < 1) {
            $error = 'No questions available. Contact administrator.';
        } else {
            // ---- WEIGHTED DIFFICULTY DISTRIBUTION ----
            // Easy:   80%E/20%M | Medium: 40%E/50%M/10%H | Hard: 20%E/40%M/40%H
            $weights = [
                'easy'   => ['easy' => 0.80, 'medium' => 0.20, 'hard' => 0.00],
                'medium' => ['easy' => 0.40, 'medium' => 0.50, 'hard' => 0.10],
                'hard'   => ['easy' => 0.20, 'medium' => 0.40, 'hard' => 0.40],
            ];
            $w = $weights[$difficulty];

            // Pull questions grouped by difficulty
            $by_diff = ['easy' => [], 'medium' => [], 'hard' => []];
            $res = mysqli_query($conn, "SELECT id, difficulty FROM questions");
            while ($row = mysqli_fetch_assoc($res)) {
                $by_diff[$row['difficulty']][] = (int) $row['id'];
            }

            // Shuffle each pool so picks are random
            foreach ($by_diff as $d => $arr) {
                shuffle($by_diff[$d]);
            }

            $selected = [];
            $total_needed = min($count, $total_questions);

            foreach (['easy', 'medium', 'hard'] as $diff) {
                $ratio = $w[$diff];
                $qty   = (int) round($total_needed * $ratio);
                $pool  = $by_diff[$diff] ?? [];
                $take  = min($qty, count($pool));
                for ($i = 0; $i < $take; $i++) {
                    $selected[] = $pool[$i];
                }
            }

            // Fill any remaining slots randomly if distribution left gaps
            // (e.g. not enough easy questions to fill 80% — fill from all pool)
            $all_ids = [];
            foreach ($by_diff as $arr) {
                foreach ($arr as $id) $all_ids[] = $id;
            }
            while (count($selected) < $total_needed) {
                $candidate = $all_ids[array_rand($all_ids)];
                if (!in_array($candidate, $selected)) {
                    $selected[] = $candidate;
                } else {
                    break;
                }
            }

            // Final shuffle so difficulty-ordered picks are interleaved
            shuffle($selected);
            $selected = array_slice($selected, 0, $total_needed);

            // Create quiz session
            $stmt = mysqli_prepare($conn, "INSERT INTO quiz_sessions (username, difficulty_mode, question_count) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'ssi', $username, $difficulty, $count);
            mysqli_stmt_execute($stmt);
            $session_id = mysqli_stmt_insert_id($stmt);
            mysqli_stmt_close($stmt);

            // Store selected questions
            $placeholders = implode(',', array_fill(0, count($selected), '(%d, %d)'));
            if ($selected) {
                $sql = "INSERT INTO session_questions (session_id, question_id) VALUES ";
                $vals = [];
                foreach ($selected as $qid) {
                    $vals[] = "($session_id, $qid)";
                }
                $sql .= implode(',', $vals);
                mysqli_query($conn, $sql);
            }

            // Store session metadata
            $_SESSION['quiz_session_id']  = $session_id;
            $_SESSION['username']         = $username;
            $_SESSION['question_index']   = 0;
            $_SESSION['quiz_count']       = $count;
            $_SESSION['quiz_difficulty']  = $difficulty;

            header("Location: quiz.php");
            exit();
        }
    }
}

$quiz_title = getSetting($conn, 'quiz_title') ?: 'Online Quiz Platform';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($quiz_title) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="home-page">

<div class="home-container">
    <!-- Left decorative panel -->
    <div class="home-panel-left">
        <div class="panel-content">
            <div class="logo-mark">Q</div>
            <h1 class="panel-title">Test Your <br><span>Knowledge</span></h1>
            <p class="panel-sub">Configure your quiz and get scored instantly across all questions.</p>
            <div class="features-list">
                <div class="feature-item">
                    <div class="feat-icon"><i class="fa-solid fa-bolt"></i></div>
                    Instant Results
                </div>
                <div class="feature-item">
                    <div class="feat-icon"><i class="fa-solid fa-shuffle"></i></div>
                    Random Questions
                </div>
                <div class="feature-item">
                    <div class="feat-icon"><i class="fa-solid fa-chart-line"></i></div>
                    Score Tracking
                </div>
                <div class="feature-item">
                    <div class="feat-icon"><i class="fa-solid fa-sliders"></i></div>
                    Difficulty Control
                </div>
            </div>
        </div>
        <div class="decorative-circles">
            <div class="circle c1"></div>
            <div class="circle c2"></div>
            <div class="circle c3"></div>
        </div>
    </div>

    <!-- Right form panel -->
    <div class="home-panel-right">
        <div class="form-card">
            <h2 class="form-card-title">Start Quiz</h2>
            <p class="form-card-sub">Enter your username and configure quiz settings</p>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="index.php" id="quizForm">
                <!-- Username -->
                <div class="mb-4">
                    <label for="username" class="form-label">Username</label>
                    <input type="text"
                           class="form-control custom-input"
                           id="username"
                           name="username"
                           placeholder="e.g. amina123"
                           value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>"
                           required
                           autofocus>
                </div>

                <!-- Question Count -->
                <div class="settings-group">
                    <div class="settings-group-label">Number of Questions</div>
                    <div class="count-selector">
                        <?php foreach ([5, 10, 15, 20] as $n): ?>
                            <button type="button"
                                    class="count-btn <?= ($_POST['question_count'] ?? 10) == $n ? 'active' : '' ?>"
                                    data-count="<?= $n ?>">
                                <?= $n ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <input type="hidden" name="question_count" id="question_count" value="<?= $_POST['question_count'] ?? 10 ?>">
                </div>

                <!-- Difficulty -->
                <div class="settings-group">
                    <div class="settings-group-label">Difficulty Level</div>
                    <div class="difficulty-selector">
                        <button type="button" class="diff-btn" data-diff="easy">
                            <div><i class="fa-solid fa-leaf"></i></div>
                            Easy
                            <div class="diff-dist">80% Easy / 20% Medium</div>
                        </button>
                        <button type="button" class="diff-btn active" data-diff="medium">
                            <div><i class="fa-solid fa-fire"></i></div>
                            Medium
                            <div class="diff-dist">40% Easy / 50% Medium / 10% Hard</div>
                        </button>
                        <button type="button" class="diff-btn" data-diff="hard">
                            <div><i class="fa-solid fa-skull"></i></div>
                            Hard
                            <div class="diff-dist">20% Easy / 40% Medium / 40% Hard</div>
                        </button>
                    </div>
                    <input type="hidden" name="difficulty" id="difficulty" value="<?= $_POST['difficulty'] ?? 'medium' ?>">
                </div>

                <button type="submit" class="btn btn-start w-100">
                    <i class="fa-solid fa-play"></i>
                    Start Quiz
                </button>
            </form>

            <div class="admin-link">
                <a href="admin/login.php">
                    <i class="fa-solid fa-lock"></i>
                    Admin Login
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.diff-dist {
    font-size: 0.65rem;
    font-weight: 400;
    color: var(--text-muted);
    margin-top: 4px;
}
.diff-btn { padding: 14px 8px; }
.diff-btn > div:first-of-type { font-size: 1.2rem; margin-bottom: 4px; }
.diff-btn.active .diff-dist { color: var(--primary); }
</style>

<script>
(function() {
    // Count selector
    document.querySelectorAll('.count-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.count-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('question_count').value = this.dataset.count;
        });
    });

    // Difficulty selector
    document.querySelectorAll('.diff-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('difficulty').value = this.dataset.diff;
        });
    });

    // Restore previous selection from POST
    var savedDiff = <?= json_encode($_POST['difficulty'] ?? 'medium') ?>;
    if (savedDiff) {
        document.querySelectorAll('.diff-btn').forEach(function(b) {
            b.classList.toggle('active', b.dataset.diff === savedDiff);
        });
        document.getElementById('difficulty').value = savedDiff;
    }

    var savedCount = <?= (int) ($_POST['question_count'] ?? 10) ?>;
    document.querySelectorAll('.count-btn').forEach(function(b) {
        b.classList.toggle('active', parseInt(b.dataset.count) === savedCount);
    });
    document.getElementById('question_count').value = savedCount;
})();
</script>
</body>
</html>