-- =============================================
-- Quiz Platform - Database Schema
-- =============================================

CREATE DATABASE IF NOT EXISTS quiz_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quiz_platform;

-- Admins table
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin: username=admin, password=admin123
INSERT INTO admins (username, password) VALUES ('admin', '$2y$10$s4/7V32fVXeRhQiCVYlj9.llVDsr/LPdEst7o7p8jDo..O7/KbGE6');

-- Categories table (optional but included for bonus)
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO categories (name) VALUES ('General'), ('Science'), ('Math'), ('History'), ('Technology');

-- Questions table
CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT DEFAULT 1,
    question_text TEXT NOT NULL,
    type ENUM('SCQ', 'MCQ') NOT NULL DEFAULT 'SCQ',
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Answers table
CREATE TABLE answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    answer_text VARCHAR(255) NOT NULL,
    is_correct TINYINT(1) DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- Settings table
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
);

INSERT INTO settings (setting_key, setting_value) VALUES
('questions_per_quiz', '10'),
('quiz_title', 'Online Quiz Platform'),
('time_limit', '0');

-- Quiz sessions table
CREATE TABLE quiz_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    difficulty_mode ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    question_count INT DEFAULT 10,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMP NULL,
    score INT DEFAULT 0,
    total INT DEFAULT 0,
    is_completed TINYINT(1) DEFAULT 0
);

-- Session questions (which questions were given to each session)
CREATE TABLE session_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    question_id INT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES quiz_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- User answers table
CREATE TABLE user_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    question_id INT NOT NULL,
    answer_id INT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES quiz_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (answer_id) REFERENCES answers(id) ON DELETE CASCADE
);

-- =============================================
-- Sample Questions
-- =============================================

-- SCQ Question 1
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'What does HTML stand for?', 'SCQ', 'easy');
SET @q1 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q1, 'HyperText Markup Language', 1),
(@q1, 'HighText Machine Language', 0),
(@q1, 'HyperText and links Markup Language', 0),
(@q1, 'None of the above', 0);

-- SCQ Question 2
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'Which language is used for styling web pages?', 'SCQ', 'easy');
SET @q2 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q2, 'HTML', 0),
(@q2, 'CSS', 1),
(@q2, 'JavaScript', 0),
(@q2, 'Python', 0);

-- MCQ Question 1
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'Which of the following are JavaScript frameworks?', 'MCQ', 'medium');
SET @q3 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q3, 'React', 1),
(@q3, 'Django', 0),
(@q3, 'Vue', 1),
(@q3, 'Laravel', 0);

-- SCQ Question 3
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (2, 'What is the speed of light?', 'SCQ', 'medium');
SET @q4 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q4, '300,000 km/s', 1),
(@q4, '150,000 km/s', 0),
(@q4, '450,000 km/s', 0),
(@q4, '100,000 km/s', 0);

-- SCQ Question 4
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (3, 'What is 2 to the power of 10?', 'SCQ', 'easy');
SET @q5 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q5, '512', 0),
(@q5, '1024', 1),
(@q5, '2048', 0),
(@q5, '256', 0);

-- MCQ Question 2
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'Which are back-end programming languages?', 'MCQ', 'medium');
SET @q6 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q6, 'PHP', 1),
(@q6, 'CSS', 0),
(@q6, 'Python', 1),
(@q6, 'HTML', 0);

-- SCQ Question 5
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (4, 'Who invented the World Wide Web?', 'SCQ', 'medium');
SET @q7 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q7, 'Bill Gates', 0),
(@q7, 'Tim Berners-Lee', 1),
(@q7, 'Steve Jobs', 0),
(@q7, 'Linus Torvalds', 0);

-- SCQ Question 6
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'What does SQL stand for?', 'SCQ', 'easy');
SET @q8 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q8, 'Structured Query Language', 1),
(@q8, 'Simple Query Language', 0),
(@q8, 'Sequential Query Language', 0),
(@q8, 'Standard Query Language', 0);

-- MCQ Question 3
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (2, 'Which are planets in our solar system?', 'MCQ', 'easy');
SET @q9 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q9, 'Mars', 1),
(@q9, 'Pluto', 0),
(@q9, 'Jupiter', 1),
(@q9, 'Sun', 0);

-- SCQ Question 7
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'What is the default port for HTTP?', 'SCQ', 'medium');
SET @q10 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q10, '8080', 0),
(@q10, '443', 0),
(@q10, '80', 1),
(@q10, '21', 0);

-- SCQ Question 8
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (3, 'What is the value of Pi (approx)?', 'SCQ', 'easy');
SET @q11 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q11, '3.14', 1),
(@q11, '3.41', 0),
(@q11, '2.14', 0),
(@q11, '3.12', 0);

-- SCQ Question 9
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (1, 'What does CPU stand for?', 'SCQ', 'easy');
SET @q12 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q12, 'Central Process Unit', 0),
(@q12, 'Central Processing Unit', 1),
(@q12, 'Computer Personal Unit', 0),
(@q12, 'Core Processing Unit', 0);

-- MCQ Question 4
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'Which are valid CSS selectors?', 'MCQ', 'hard');
SET @q13 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q13, '.class', 1),
(@q13, '#id', 1),
(@q13, '$$element', 0),
(@q13, 'element', 1);

-- SCQ Question 10
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (4, 'In which year was the first iPhone released?', 'SCQ', 'medium');
SET @q14 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q14, '2005', 0),
(@q14, '2007', 1),
(@q14, '2009', 0),
(@q14, '2010', 0);

-- SCQ Question 11
INSERT INTO questions (category_id, question_text, type, difficulty) VALUES (5, 'Which PHP function is used to connect to MySQL?', 'SCQ', 'hard');
SET @q15 = LAST_INSERT_ID();
INSERT INTO answers (question_id, answer_text, is_correct) VALUES
(@q15, 'mysql_connect()', 0),
(@q15, 'mysqli_connect()', 1),
(@q15, 'db_connect()', 0),
(@q15, 'connect_mysql()', 0);
