<?php
// =============================================
// includes/db.php - Database Connection
// =============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'quiz_user');       // غيّري هذا لاسم مستخدم MySQL عندك
define('DB_PASS', '1234');           // غيّري هذا لكلمة مرور MySQL عندك
define('DB_NAME', 'quiz_platform');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

// Helper: get setting value
function getSetting($conn, $key) {
    $key = mysqli_real_escape_string($conn, $key);
    $result = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = '$key'");
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['setting_value'];
    }
    return null;
}
?>



