<?php
// =============================================
// includes/auth.php - Session Authentication
// =============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
function requireAdmin() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Check if quiz session is active
function requireQuizSession() {
    if (!isset($_SESSION['quiz_session_id'])) {
        header("Location: ../index.php");
        exit();
    }
}
?>
